import React, { useState, useEffect, useRef, memo } from 'react';
import { HashRouter } from 'react-router-dom';
import { 
  Activity, 
  Layers, 
  Play, 
  Pause,
  BarChart3, 
  TrendingUp, 
  Settings, 
  AlertTriangle,
  ChevronRight,
  Database,
  Terminal,
  Cpu,
  Zap,
  RotateCcw,
  Maximize2,
  Download,
  Target,
  ShieldAlert,
  Move,
  Search
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Legend,
  ScatterChart,
  Scatter,
  Brush,
  ReferenceArea
} from 'recharts';
import { SectionID, TrackedObject } from './types';
import { SYSTEM_CONFIG } from './constants';
import { SimulationEngine } from './services/simulationEngine';

// --- Reusable Components ---

const Card = memo(({ title, children, className, extra }: { title: string; children: React.ReactNode; className?: string; extra?: React.ReactNode }) => (
  <div className={`bg-slate-800/50 border border-slate-700 rounded-xl overflow-hidden backdrop-blur-sm flex flex-col ${className}`}>
    <div className="px-6 py-4 border-b border-slate-700 bg-slate-800/80 flex justify-between items-center">
      <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">{title}</h3>
      {extra}
    </div>
    <div className="p-6 flex-1">
      {children}
    </div>
  </div>
));

const Metric = memo(({ label, value, sub }: { label: string; value: string | number; sub?: string }) => (
  <div className="flex flex-col">
    <span className="text-xs text-slate-400 font-medium uppercase">{label}</span>
    <span className="text-2xl font-bold text-white mono">{value}</span>
    {sub && <span className="text-xs text-blue-400 mt-1">{sub}</span>}
  </div>
));

// --- Custom Tooltips ---

const VelocityTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl text-[10px] mono">
        <p className="text-slate-400 mb-2 border-b border-slate-700 pb-1">Frame Reference: {label}</p>
        {payload.map((p: any, i: number) => (
          <div key={i} className="flex justify-between gap-4 mb-0.5">
            <span style={{ color: p.color }}>{p.name}:</span>
            <span className="text-white font-bold">{p.value.toFixed(3)} px/fr</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const PositionTimeTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg shadow-xl text-[10px] mono">
        <p className="text-slate-400 mb-2 border-b border-slate-700 pb-1">Frame Reference: {label}</p>
        {payload.map((p: any, i: number) => (
          <div key={i} className="flex justify-between gap-4 mb-0.5">
            <span style={{ color: p.color }}>{p.name}:</span>
            <span className="text-white font-bold">{p.value.toFixed(2)} px</span>
          </div>
        ))}
      </div>
    );
  }
  return null;
};

const PositionNoiseTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const seriesName = payload[0].name;
    const isRaw = seriesName === 'Raw Observations';
    
    return (
      <div className="bg-slate-900/95 border border-slate-700 p-3 rounded-lg shadow-2xl text-[10px] mono min-w-[170px] backdrop-blur-md">
        <div className="flex items-center justify-between mb-2 border-b border-slate-700 pb-1.5 gap-4">
          <span className={`font-bold uppercase tracking-widest ${isRaw ? 'text-red-400' : 'text-blue-400'}`}>
            {isRaw ? 'RAW_SENSOR' : 'FILTER_EST'}
          </span>
          <div className={`w-2 h-2 rounded-full shadow-[0_0_8px_rgba(255,255,255,0.3)] ${isRaw ? 'bg-red-500' : 'bg-blue-500'}`} />
        </div>
        <div className="space-y-1.5">
          <div className="flex justify-between items-center">
            <span className="text-slate-500 text-[9px]">TIME_REF [t]:</span>
            <span className="text-white font-bold">{data.t}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-500 text-[9px]">COORD_X [px]:</span>
            <span className="text-white font-bold">{data.x.toFixed(3)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-500 text-[9px]">COORD_Y [px]:</span>
            <span className="text-white font-bold">{data.y.toFixed(3)}</span>
          </div>
          <div className="flex justify-between border-t border-slate-800 pt-1.5 mt-1">
            <span className="text-slate-500 text-[8px] uppercase">Telemetry:</span>
            <span className="text-slate-400 text-[8px] font-medium">{isRaw ? 'UNCORRECTED' : 'KF_PREDICTION'}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

// --- Main App Component ---

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<SectionID>(SectionID.OVERVIEW);
  const [simData, setSimData] = useState<TrackedObject[]>([]);
  const [isPaused, setIsPaused] = useState(false);
  const [selectedObjectId, setSelectedObjectId] = useState<string | null>(null);
  
  // Chart Interaction States
  const [showRaw, setShowRaw] = useState(true);
  const [showFiltered, setShowFiltered] = useState(true);
  const [hoveredSeries, setHoveredSeries] = useState<string | null>(null);
  const [interactionMode, setInteractionMode] = useState<'zoom' | 'pan'>('zoom');
  const [velocityBrushKey, setVelocityBrushKey] = useState(0); 
  const [posTimeBrushKey, setPosTimeBrushKey] = useState(0);

  const [scatterZoom, setScatterZoom] = useState({
    left: 'dataMin' as any,
    right: 'dataMax' as any,
    top: 'dataMin' as any,
    bottom: 'dataMax' as any,
    refAreaLeft: null as any,
    refAreaRight: null as any,
    refAreaTop: null as any,
    refAreaBottom: null as any,
    isDragging: false,
    startX: 0,
    startY: 0
  });

  const engineRef = useRef<SimulationEngine | null>(null);

  useEffect(() => {
    engineRef.current = new SimulationEngine();
    const interval = setInterval(() => {
      if (engineRef.current && !isPaused) {
        const data = engineRef.current.step();
        setSimData(data);
        if (selectedObjectId === null && data.length > 0) {
          setSelectedObjectId(data[0].id);
        }
      }
    }, 1000 / SYSTEM_CONFIG.FRAME_RATE);
    return () => clearInterval(interval);
  }, [isPaused, selectedObjectId]);

  const scrollToSection = (id: SectionID) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const selectedObject = simData.find(obj => obj.id === selectedObjectId) || simData[0];

  const handleExportCSV = () => {
    if (!selectedObject) return;

    const headers = ['timestamp', 'x', 'y', 'vx', 'vy', 'type'];
    const historyRows = selectedObject.history.map(h => [
      h.t, h.x, h.y, h.vx, h.vy, 'HISTORY'
    ]);
    const predictionRows = selectedObject.prediction.map(p => [
      p.t, p.x, p.y, selectedObject.vx, selectedObject.vy, 'PREDICTION'
    ]);

    const csvContent = [
      headers.join(','),
      ...historyRows.map(row => row.join(',')),
      ...predictionRows.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `telemetry_${selectedObject.id}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleScatterMouseDown = (e: any) => {
    if (!e) return;
    if (interactionMode === 'zoom') {
      setScatterZoom(prev => ({ ...prev, refAreaLeft: e.xValue, refAreaTop: e.yValue, isDragging: true }));
    } else {
      setScatterZoom(prev => ({ ...prev, startX: e.xValue, startY: e.yValue, isDragging: true }));
    }
  };

  const handleScatterMouseMove = (e: any) => {
    if (!e || !scatterZoom.isDragging) return;
    
    if (interactionMode === 'zoom') {
      setScatterZoom(prev => ({ ...prev, refAreaRight: e.xValue, refAreaBottom: e.yValue }));
    } else {
      const dx = scatterZoom.startX - e.xValue;
      const dy = scatterZoom.startY - e.yValue;
      
      setScatterZoom(prev => {
        const currentLeft = prev.left === 'dataMin' ? (selectedObject?.history[0]?.x || 0) : prev.left;
        const currentRight = prev.right === 'dataMax' ? (selectedObject?.history[selectedObject.history.length-1]?.x || 640) : prev.right;
        const currentTop = prev.top === 'dataMin' ? (Math.min(...selectedObject?.history.map(h => h.y) || [0])) : prev.top;
        const currentBottom = prev.bottom === 'dataMax' ? (Math.max(...selectedObject?.history.map(h => h.y) || [480])) : prev.bottom;

        return {
          ...prev,
          left: currentLeft + dx,
          right: currentRight + dx,
          top: currentTop + dy,
          bottom: currentBottom + dy,
          startX: e.xValue,
          startY: e.yValue
        };
      });
    }
  };

  const handleScatterMouseUp = () => {
    if (interactionMode === 'zoom') {
      const { refAreaLeft, refAreaRight, refAreaTop, refAreaBottom } = scatterZoom;
      if (refAreaLeft === refAreaRight || refAreaRight === null) {
        setScatterZoom(prev => ({ ...prev, refAreaLeft: null, refAreaRight: null, refAreaTop: null, refAreaBottom: null, isDragging: false }));
        return;
      }
      const [left, right] = refAreaLeft < refAreaRight ? [refAreaLeft, refAreaRight] : [refAreaRight, refAreaLeft];
      const [bottom, top] = refAreaTop < refAreaBottom ? [refAreaTop, refAreaBottom] : [refAreaBottom, refAreaTop];

      setScatterZoom({
        left,
        right,
        top,
        bottom,
        refAreaLeft: null,
        refAreaRight: null,
        refAreaTop: null,
        refAreaBottom: null,
        isDragging: false,
        startX: 0,
        startY: 0
      });
    } else {
      setScatterZoom(prev => ({ ...prev, isDragging: false }));
    }
  };

  const resetScatterZoom = () => {
    setScatterZoom({
      left: 'dataMin',
      right: 'dataMax',
      top: 'dataMin',
      bottom: 'dataMax',
      refAreaLeft: null,
      refAreaRight: null,
      refAreaTop: null,
      refAreaBottom: null,
      isDragging: false,
      startX: 0,
      startY: 0
    });
  };

  const resetVelocityView = () => setVelocityBrushKey(prev => prev + 1);
  const resetPosTimeView = () => setPosTimeBrushKey(prev => prev + 1);

  const handleLegendClick = (data: any) => {
    if (data.value === 'Raw Observations' || data.value === 'Raw X' || data.value === 'Raw Y') {
      setShowRaw(!showRaw);
    } else if (data.value === 'Filtered Prediction' || data.value === 'Smooth X' || data.value === 'Smooth Y') {
      setShowFiltered(!showFiltered);
    }
  };

  const navItems = [
    { id: SectionID.OVERVIEW, label: 'Overview', icon: <Activity size={18} /> },
    { id: SectionID.ARCHITECTURE, label: 'Architecture', icon: <Layers size={18} /> },
    { id: SectionID.DEMO, label: 'Live Demo', icon: <Play size={18} /> },
    { id: SectionID.RESULTS, label: 'Tracking Results', icon: <BarChart3 size={18} /> },
    { id: SectionID.PREDICTION, label: 'Prediction', icon: <TrendingUp size={18} /> },
    { id: SectionID.METRICS, label: 'Performance', icon: <Settings size={18} /> },
    { id: SectionID.LIMITATIONS, label: 'Assumptions', icon: <AlertTriangle size={18} /> },
  ];

  return (
    <HashRouter>
      <div className="min-h-screen flex flex-col">
        {/* Sticky Header Nav */}
        <nav className="sticky top-0 z-50 bg-slate-900/90 border-b border-slate-800 backdrop-blur-md px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Zap className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white leading-tight">SatTrack Alpha</h1>
              <p className="text-[10px] text-slate-400 uppercase tracking-widest font-semibold">Estimation Prototype v1.0.4</p>
            </div>
          </div>
          <div className="hidden lg:flex gap-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  activeSection === item.id 
                    ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsPaused(!isPaused)}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold border transition-all ${
                isPaused 
                  ? 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20 hover:bg-yellow-500/20' 
                  : 'bg-green-500/10 text-green-400 border-green-500/20 hover:bg-green-500/20'
              }`}
            >
              {isPaused ? <Play size={14} fill="currentColor" /> : <Pause size={14} fill="currentColor" />}
              {isPaused ? 'RESUME SIM' : 'SIMULATING'}
            </button>
          </div>
        </nav>

        <main className="flex-1 overflow-y-auto">
          {/* 1. Overview */}
          <section id={SectionID.OVERVIEW} className="min-h-screen flex flex-col justify-center px-6 lg:px-24 py-20 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-blue-900/20 via-slate-900 to-slate-900">
            <div className="max-w-4xl">
              <span className="inline-block px-3 py-1 bg-blue-500/10 text-blue-400 text-xs font-bold rounded-full mb-6 border border-blue-500/20 uppercase tracking-widest">
                Technical Specification
              </span>
              <h2 className="text-5xl lg:text-7xl font-bold text-white mb-8 tracking-tight leading-tight">
                Defensible Tracking for <span className="text-blue-500">Autonomous Orbitals.</span>
              </h2>
              <p className="text-xl text-slate-400 mb-12 leading-relaxed">
                SatTrack Alpha implements a near real-time estimator designed for high-velocity satellite debris. By leveraging 
                synthetic video streams, the prototype demonstrates precise state estimation and multi-frame trajectory prediction 
                under noisy observation models.
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8 p-8 bg-slate-800/40 rounded-2xl border border-slate-700/50 backdrop-blur-xl">
                <Metric label="Resolution" value={SYSTEM_CONFIG.RESOLUTION} sub="Pixels" />
                <Metric label="Frame Rate" value={SYSTEM_CONFIG.FRAME_RATE} sub="FPS (Constant)" />
                <Metric label="Tracked Objects" value={SYSTEM_CONFIG.OBJECT_COUNT} sub="Active Entities" />
                <Metric label="Latency" value="12.4" sub="ms / frame" />
              </div>
            </div>
          </section>

          {/* 2. System Architecture */}
          <section id={SectionID.ARCHITECTURE} className="py-24 px-6 lg:px-24 bg-slate-950">
            <div className="mb-16">
              <h2 className="text-3xl font-bold text-white mb-4">System Architecture</h2>
              <p className="text-slate-400 max-w-2xl">A modular approach to high-fidelity state estimation, separating visual extraction from recursive filter dynamics.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <Card title="Detection Pipeline">
                <div className="space-y-4">
                  <div className="flex items-start gap-4 p-4 bg-slate-900/50 rounded-lg border border-slate-700/30">
                    <div className="p-2 bg-blue-500/10 rounded border border-blue-500/20">
                      <Terminal size={20} className="text-blue-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Intensity Thresholding</h4>
                      <p className="text-xs text-slate-500 mt-1">Binary mask generation using adaptive luminance thresholds for debris isolation.</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4 p-4 bg-slate-900/50 rounded-lg border border-slate-700/30">
                    <div className="p-2 bg-emerald-500/10 rounded border border-emerald-500/20">
                      <Cpu size={20} className="text-emerald-400" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Centroid Extraction</h4>
                      <p className="text-xs text-slate-500 mt-1">First-order moment analysis to determine object coordinates (x, y) per frame.</p>
                    </div>
                  </div>
                </div>
              </Card>

              <Card title="Tracking Core">
                <div className="space-y-4">
                  <div className="p-4 bg-blue-600/10 rounded-lg border border-blue-500/30 text-center">
                    <h4 className="text-lg font-bold text-white mono">Kalman Filter v2</h4>
                    <p className="text-xs text-blue-400 mt-1 italic">Recursive Prediction-Correction</p>
                  </div>
                  <ul className="space-y-3">
                    <li className="flex items-center gap-3 text-sm text-slate-300">
                      <ChevronRight size={14} className="text-blue-500" />
                      Nearest-Neighbor Association
                    </li>
                    <li className="flex items-center gap-3 text-sm text-slate-300">
                      <ChevronRight size={14} className="text-blue-500" />
                      State Vector [x, y, vx, vy]
                    </li>
                    <li className="flex items-center gap-3 text-sm text-slate-300">
                      <ChevronRight size={14} className="text-blue-500" />
                      Constant Velocity Assumption
                    </li>
                  </ul>
                </div>
              </Card>

              <Card title="Output Modules">
                <div className="grid grid-cols-1 gap-4">
                   <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700/30">
                      <p className="text-xs font-bold text-slate-400 uppercase mb-2">Estimation</p>
                      <p className="text-sm text-white">Trajectory Prediction Horizon: {SYSTEM_CONFIG.PREDICTION_HORIZON} Frames</p>
                   </div>
                   <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700/30">
                      <p className="text-xs font-bold text-slate-400 uppercase mb-2">Warnings</p>
                      <p className="text-sm text-white">Proximity & Impact Collision Logic</p>
                   </div>
                </div>
              </Card>
            </div>
          </section>

          {/* 3. Live Demo Section */}
          <section id={SectionID.DEMO} className="py-24 px-6 lg:px-24 bg-slate-900">
            <div className="flex flex-col lg:flex-row gap-12">
              <div className="flex-1">
                <div className="mb-8">
                  <h2 className="text-3xl font-bold text-white mb-4">Live Tracking Demo</h2>
                  <p className="text-slate-400">Real-time visualization of centroid tracking and vector estimation on synthetic satellite feeds.</p>
                </div>
                
                <div className="relative aspect-video bg-black rounded-2xl border-4 border-slate-800 overflow-hidden shadow-2xl">
                  {/* Simulated Visual Overlay */}
                  <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 640 480">
                    <defs>
                      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#ffffff08" strokeWidth="1"/>
                      </pattern>
                    </defs>
                    <rect width="100%" height="100%" fill="url(#grid)" />

                    {simData.map((obj) => (
                      <g key={obj.id}>
                        <polyline
                          points={obj.history.map(p => `${p.x},${p.y}`).join(' ')}
                          fill="none"
                          stroke={obj.color}
                          strokeWidth="1.5"
                          strokeDasharray="4 2"
                          opacity="0.4"
                        />
                        <polyline
                          points={`${obj.x},${obj.y} ` + obj.prediction.map(p => `${p.x},${p.y}`).join(' ')}
                          fill="none"
                          stroke={obj.color}
                          strokeWidth="2"
                          strokeDasharray="2 4"
                        />
                        <rect
                          x={obj.x - 12}
                          y={obj.y - 12}
                          width="24"
                          height="24"
                          fill="none"
                          stroke={obj.color}
                          strokeWidth="2"
                        />
                        <text x={obj.x + 18} y={obj.y - 18} className="text-[10px] mono" fill={obj.color} fontWeight="bold">
                          {obj.id}
                        </text>
                        <text x={obj.x + 18} y={obj.y - 6} className="text-[8px] mono" fill="white" opacity="0.8">
                          v: {Math.sqrt(obj.vx**2 + obj.vy**2).toFixed(2)} px/fr
                        </text>
                        <line 
                          x1={obj.x} y1={obj.y} 
                          x2={obj.x + obj.vx * 10} y2={obj.y + obj.vy * 10} 
                          stroke={obj.color} strokeWidth="1" 
                        />
                      </g>
                    ))}
                  </svg>
                  
                  <div className="absolute top-4 left-4 bg-slate-950/80 backdrop-blur-md border border-slate-700 p-3 rounded-lg flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-[10px] font-bold text-white tracking-widest mono">SENSOR_FEED::ACTIVE</span>
                    </div>
                    <span className="text-[8px] text-slate-500 mono uppercase">Enc: H.264 | Res: 640x480</span>
                  </div>
                </div>
              </div>

              <div className="w-full lg:w-96 space-y-6">
                <Card title="Active Telemetry">
                  <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                    {simData.map((obj) => (
                      <div 
                        key={obj.id} 
                        onClick={() => setSelectedObjectId(obj.id)}
                        className={`p-3 rounded-lg border cursor-pointer transition-all flex flex-col gap-2 ${
                          selectedObjectId === obj.id 
                            ? 'bg-blue-600/10 border-blue-500/50 shadow-lg shadow-blue-500/5' 
                            : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-2">
                            <Target size={12} className={selectedObjectId === obj.id ? 'text-blue-400' : 'text-slate-600'} />
                            <span className={`text-xs font-bold mono ${selectedObjectId === obj.id ? 'text-blue-400' : 'text-white'}`}>{obj.id}</span>
                          </div>
                          <span className="px-2 py-0.5 bg-blue-500/10 text-blue-400 text-[10px] rounded border border-blue-500/20 mono uppercase">Locked</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-400 mono">
                          <div>POS_X: {obj.x.toFixed(1)}</div>
                          <div>POS_Y: {obj.y.toFixed(1)}</div>
                          <div>VEL_X: {obj.vx.toFixed(2)}</div>
                          <div>VEL_Y: {obj.vy.toFixed(2)}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </Card>
              </div>
            </div>
          </section>

          {/* 4. Tracking Results Section */}
          <section id={SectionID.RESULTS} className="py-24 px-6 lg:px-24 bg-slate-950">
            <div className="mb-12 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
              <div>
                <h2 className="text-3xl font-bold text-white mb-4">Tracking Stability & Velocity Results</h2>
                <p className="text-slate-400">Analyzing the variance for <span className="text-blue-400 font-bold mono">{selectedObjectId}</span>. Charts support pan/zoom interaction.</p>
              </div>
              <button 
                onClick={handleExportCSV}
                className="flex items-center gap-2 px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-sm font-bold transition-all shadow-lg shadow-blue-600/20 uppercase tracking-wider"
              >
                <Download size={18} />
                Export Telemetry (CSV)
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card 
                title={`Velocity Profile - ${selectedObjectId}`} 
                extra={
                  <div className="flex items-center gap-4">
                    <button onClick={resetVelocityView} className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors bg-slate-700/50 px-2 py-1 rounded">
                      <RotateCcw size={12} /> Reset
                    </button>
                  </div>
                }
              >
                <div className="h-[300px] w-full flex flex-col">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={selectedObject?.history || []}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="t" stroke="#94a3b8" fontSize={10} name="Frame" />
                      <YAxis stroke="#94a3b8" fontSize={10} />
                      <Tooltip content={<VelocityTooltip />} />
                      <Legend verticalAlign="top" height={36} />
                      <Line type="monotone" dataKey="vx" stroke="#3b82f6" dot={false} strokeWidth={2} name="Vel X (px/fr)" />
                      <Line type="monotone" dataKey="vy" stroke="#10b981" dot={false} strokeWidth={2} name="Vel Y (px/fr)" />
                      <Brush key={velocityBrushKey} dataKey="t" height={30} stroke="#3b82f6" fill="#0f172a" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card 
                title={`Position Over Time - ${selectedObjectId}`} 
                extra={
                  <div className="flex items-center gap-4">
                    <button onClick={resetPosTimeView} className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors bg-slate-700/50 px-2 py-1 rounded">
                      <RotateCcw size={12} /> Reset
                    </button>
                  </div>
                }
              >
                <div className="h-[300px] w-full flex flex-col">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={selectedObject?.history || []}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="t" stroke="#94a3b8" fontSize={10} name="Frame" />
                      <YAxis stroke="#94a3b8" fontSize={10} />
                      <Tooltip content={<PositionTimeTooltip />} />
                      <Legend 
                        verticalAlign="top" 
                        height={36} 
                        onClick={handleLegendClick}
                        wrapperStyle={{ cursor: 'pointer' }}
                        formatter={(value) => (
                          <span className={`text-[10px] font-bold uppercase tracking-wider transition-opacity ${
                            (value.includes('Raw') && !showRaw) || (value.includes('Smooth') && !showFiltered) 
                              ? 'opacity-30' 
                              : 'opacity-100'
                          }`}>
                            {value}
                          </span>
                        )}
                      />
                      {showRaw && <Line type="monotone" dataKey="x" stroke="#ef4444" strokeDasharray="4 4" dot={false} strokeWidth={1} name="Raw X" />}
                      {showRaw && <Line type="monotone" dataKey="y" stroke="#f59e0b" strokeDasharray="4 4" dot={false} strokeWidth={1} name="Raw Y" />}
                      {showFiltered && <Line type="monotone" dataKey="sx" stroke="#3b82f6" dot={false} strokeWidth={2} name="Smooth X" />}
                      {showFiltered && <Line type="monotone" dataKey="sy" stroke="#10b981" dot={false} strokeWidth={2} name="Smooth Y" />}
                      <Brush key={posTimeBrushKey} dataKey="t" height={30} stroke="#3b82f6" fill="#0f172a" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card 
                title={`Position Noise Analysis - ${selectedObjectId}`} 
                extra={
                  <div className="flex gap-2">
                    <div className="flex bg-slate-900 rounded p-1 border border-slate-700">
                      <button 
                        onClick={() => setInteractionMode('zoom')}
                        title="Zoom Mode"
                        className={`p-1.5 rounded transition-all ${interactionMode === 'zoom' ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/40' : 'text-slate-500 hover:text-slate-300'}`}
                      >
                        <Search size={14} />
                      </button>
                      <button 
                        onClick={() => setInteractionMode('pan')}
                        title="Pan Mode"
                        className={`p-1.5 rounded transition-all ${interactionMode === 'pan' ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/40' : 'text-slate-500 hover:text-slate-300'}`}
                      >
                        <Move size={14} />
                      </button>
                    </div>
                    <button onClick={resetScatterZoom} className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors bg-slate-700/50 px-2 py-1 rounded">
                      <RotateCcw size={12} /> Reset
                    </button>
                  </div>
                }
              >
                <div className={`h-[300px] w-full select-none ${interactionMode === 'zoom' ? 'cursor-crosshair' : 'cursor-grab active:cursor-grabbing'}`}>
                  <ResponsiveContainer width="100%" height="100%">
                    <ScatterChart 
                      onMouseDown={handleScatterMouseDown}
                      onMouseMove={handleScatterMouseMove}
                      onMouseUp={handleScatterMouseUp}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis 
                        type="number" 
                        dataKey="x" 
                        name="Pos X" 
                        unit="px" 
                        stroke="#94a3b8" 
                        fontSize={10} 
                        domain={[scatterZoom.left, scatterZoom.right]} 
                        allowDataOverflow
                      />
                      <YAxis 
                        type="number" 
                        dataKey="y" 
                        name="Pos Y" 
                        unit="px" 
                        stroke="#94a3b8" 
                        fontSize={10} 
                        domain={[scatterZoom.bottom, scatterZoom.top]} 
                        allowDataOverflow
                      />
                      <Tooltip content={<PositionNoiseTooltip />} cursor={{ strokeDasharray: '3 3' }} />
                      <Legend 
                        verticalAlign="top" 
                        height={36} 
                        onClick={handleLegendClick}
                        wrapperStyle={{ cursor: 'pointer' }}
                        formatter={(value) => (
                          <span className={`text-[10px] font-bold uppercase tracking-wider transition-opacity ${
                            (value === 'Raw Observations' && !showRaw) || (value === 'Filtered Prediction' && !showFiltered) 
                              ? 'opacity-30' 
                              : 'opacity-100'
                          }`}>
                            {value}
                          </span>
                        )}
                      />
                      {showRaw && (
                        <Scatter 
                          name="Raw Observations" 
                          data={selectedObject?.history || []} 
                          fill="#ef4444" 
                          opacity={hoveredSeries === 'Filtered Prediction' ? 0.2 : 0.6}
                          onMouseEnter={() => setHoveredSeries('Raw Observations')}
                          onMouseLeave={() => setHoveredSeries(null)}
                        />
                      )}
                      {showFiltered && (
                        <Scatter 
                          name="Filtered Prediction" 
                          data={selectedObject?.prediction || []} 
                          fill="#3b82f6" 
                          shape="cross"
                          opacity={hoveredSeries === 'Raw Observations' ? 0.2 : 1}
                          onMouseEnter={() => setHoveredSeries('Filtered Prediction')}
                          onMouseLeave={() => setHoveredSeries(null)}
                        />
                      )}
                      {interactionMode === 'zoom' && scatterZoom.refAreaLeft && scatterZoom.refAreaRight && (
                        <ReferenceArea 
                          x1={scatterZoom.refAreaLeft} 
                          x2={scatterZoom.refAreaRight} 
                          y1={scatterZoom.refAreaTop} 
                          y2={scatterZoom.refAreaBottom} 
                          strokeOpacity={0.3} 
                          fill="#3b82f6"
                          fillOpacity={0.1}
                        />
                      )}
                    </ScatterChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <Card title="Velocity Error (RMSE)" extra={<BarChart3 size={16} className="text-blue-500" />}>
                <div className="space-y-8">
                  <div className="flex justify-between items-end border-b border-slate-800 pb-4">
                    <Metric label="Mean Pos Error" value="0.42" sub="Pixels" />
                    <div className="h-8 w-1/2 bg-blue-500/10 rounded-full relative overflow-hidden">
                       <div className="absolute top-0 left-0 h-full bg-blue-600 rounded-full" style={{ width: '15%' }} />
                    </div>
                  </div>
                  <div className="flex justify-between items-end border-b border-slate-800 pb-4">
                    <Metric label="Max Vel Error" value="0.87" sub="Pixels / Frame" />
                    <div className="h-8 w-1/2 bg-emerald-500/10 rounded-full relative overflow-hidden">
                       <div className="absolute top-0 left-0 h-full bg-emerald-600 rounded-full" style={{ width: '22%' }} />
                    </div>
                  </div>
                  <div className="flex justify-between items-end">
                    <Metric label="Continuity Score" value="99.2" sub="%" />
                    <div className="h-8 w-1/2 bg-blue-500/10 rounded-full relative overflow-hidden">
                       <div className="absolute top-0 left-0 h-full bg-blue-600 rounded-full" style={{ width: '99%' }} />
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </section>

          {/* 5. Trajectory Prediction Section */}
          <section id={SectionID.PREDICTION} className="py-24 px-6 lg:px-24 bg-slate-900">
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div>
                   <h2 className="text-3xl font-bold text-white mb-6">Forward Reasoning & Prediction</h2>
                   <p className="text-slate-400 mb-8 leading-relaxed">
                     The system projectively estimates future states by propagating the current covariance and mean state through 
                     the motion model. This allows for early collision detection and proximity warning flags.
                   </p>
                   <div className="space-y-4">
                      <div className="flex items-center gap-4">
                         <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xs">01</div>
                         <div>
                            <h4 className="text-white font-bold">Horizon Scaling</h4>
                            <p className="text-xs text-slate-500">Configurable 5-50 frame look-ahead based on mission criticality.</p>
                         </div>
                      </div>
                      <div className="flex items-center gap-4">
                         <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-xs">02</div>
                         <div>
                            <h4 className="text-white font-bold">Collision Matrix</h4>
                            <p className="text-xs text-slate-500">Automated impact point calculation relative to sensor field boundaries.</p>
                         </div>
                      </div>
                   </div>
                </div>
                <div className="flex flex-col gap-6">
                  <div className="p-8 bg-slate-800/50 rounded-2xl border border-slate-700 shadow-xl">
                    <h4 className="text-xs font-bold text-slate-400 uppercase mb-6 tracking-widest">Prediction Parameters</h4>
                    <table className="w-full text-sm">
                        <thead>
                          <tr className="text-slate-500 border-b border-slate-700">
                            <th className="text-left py-2 font-medium">Metric</th>
                            <th className="text-right py-2 font-medium">Config Value</th>
                          </tr>
                        </thead>
                        <tbody className="mono text-slate-300">
                          <tr>
                            <td className="py-3 border-b border-slate-700/30 text-blue-400">HORIZON_FRAMES</td>
                            <td className="py-3 border-b border-slate-700/30 text-right">{SYSTEM_CONFIG.PREDICTION_HORIZON}</td>
                          </tr>
                          <tr>
                            <td className="py-3 border-b border-slate-700/30 text-blue-400">TIME_LOOKAHEAD</td>
                            <td className="py-3 border-b border-slate-700/30 text-right">1.0s</td>
                          </tr>
                          <tr>
                            <td className="py-3 border-b border-slate-700/30 text-blue-400">CONFIDENCE_LMT</td>
                            <td className="py-3 border-b border-slate-700/30 text-right">0.95</td>
                          </tr>
                          <tr>
                            <td className="py-3 text-blue-400">COLLISION_THR</td>
                            <td className="py-3 text-right">5.0m</td>
                          </tr>
                        </tbody>
                    </table>
                  </div>

                  <Card title="Prediction Accuracy" extra={<ShieldAlert size={16} className="text-blue-500" />}>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700/30">
                        <Metric label="Mean Prediction Error" value="1.24" sub="Pixels (Horizon)" />
                      </div>
                      <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700/30">
                        <Metric label="Max Prediction Error" value="3.82" sub="Pixels @ Limit" />
                      </div>
                    </div>
                  </Card>
                </div>
             </div>
          </section>

          {/* 6. Performance Metrics Section */}
          <section id={SectionID.METRICS} className="py-24 px-6 lg:px-24 bg-slate-950">
            <div className="mb-12">
              <h2 className="text-3xl font-bold text-white mb-4">Engineering Credentials</h2>
              <p className="text-slate-400">System-level performance indicators ensuring computational feasibility in resource-constrained environments.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Processing FPS', value: '120+', icon: <Zap className="text-yellow-500" /> },
                { label: 'Avg Latency', value: '8.2ms', icon: <Activity className="text-blue-500" /> },
                { label: 'CPU Load', value: '14%', icon: <Cpu className="text-purple-500" /> },
                { label: 'Memory', value: '42MB', icon: <Database className="text-emerald-500" /> },
              ].map((m, i) => (
                <div key={i} className="p-6 bg-slate-900 border border-slate-800 rounded-xl hover:border-slate-700 transition-colors">
                  <div className="mb-4">{m.icon}</div>
                  <div className="text-2xl font-bold text-white mono mb-1">{m.value}</div>
                  <div className="text-xs text-slate-500 font-medium uppercase tracking-wider">{m.label}</div>
                </div>
              ))}
            </div>
          </section>

          {/* 7. Limitations Section */}
          <section id={SectionID.LIMITATIONS} className="py-24 px-6 lg:px-24 bg-slate-900 border-t border-slate-800">
             <div className="max-w-4xl mx-auto">
                <div className="mb-12 text-center">
                  <h2 className="text-3xl font-bold text-white mb-4">Limitations & Assumptions</h2>
                  <p className="text-slate-400">Scientific transparency regarding the scope and operational envelope of this prototype.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="p-6 bg-slate-800/30 rounded-xl border border-slate-700">
                      <h4 className="text-white font-bold mb-4 flex items-center gap-2">
                         <ChevronRight className="text-blue-500" /> Fundamental Assumptions
                      </h4>
                      <ul className="space-y-3 text-sm text-slate-400">
                        <li>• Motion is assumed linear within prediction windows.</li>
                        <li>• Fixed frame rate (20 FPS) is used for time-delta calculations.</li>
                        <li>• Objects are treated as point-masses for centroid estimation.</li>
                        <li>• Sensor noise is modeled as Gaussian White Noise.</li>
                      </ul>
                   </div>
                   <div className="p-6 bg-slate-800/30 rounded-xl border border-slate-700">
                      <h4 className="text-white font-bold mb-4 flex items-center gap-2">
                         <ChevronRight className="text-red-500" /> Identified Limitations
                      </h4>
                      <ul className="space-y-3 text-sm text-slate-400">
                        <li>• Monocular setup lacks depth perception (Z-axis).</li>
                        <li>• No handling for complex atmospheric or orbital perturbations.</li>
                        <li>• Occlusion management (object passing behind another) is not implemented.</li>
                        <li>• High-blur scenarios may degrade centroid accuracy.</li>
                      </ul>
                   </div>
                </div>
             </div>
          </section>

          <footer className="py-12 px-6 lg:px-24 bg-slate-950 border-t border-slate-800">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6">
              <div className="flex items-center gap-2 opacity-50">
                <Zap size={16} />
                <span className="text-xs font-bold uppercase tracking-widest text-white">SatTrack Alpha v1.0.4</span>
              </div>
              <div className="text-[10px] text-slate-500 mono uppercase tracking-tighter">
                &copy; 2024 Project Aerospace Estimator | For Technical Examination Purposes Only
              </div>
            </div>
          </footer>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;