import { TrackedObject } from '../types';
import { SYSTEM_CONFIG, COLORS } from '../constants';

export class SimulationEngine {
  private objects: TrackedObject[] = [];
  private frameCount: number = 0;

  constructor() {
    this.init();
  }

  private init() {
    this.objects = Array.from({ length: SYSTEM_CONFIG.OBJECT_COUNT }).map((_, i) => ({
      id: `SAT-${(i + 1).toString().padStart(3, '0')}`,
      x: Math.random() * 640,
      y: Math.random() * 480,
      vx: (Math.random() - 0.5) * 4,
      vy: (Math.random() - 0.5) * 4,
      history: [],
      prediction: [],
      color: COLORS[i % COLORS.length]
    }));
  }

  public step(): TrackedObject[] {
    this.frameCount++;
    
    this.objects = this.objects.map(obj => {
      // Basic constant velocity motion
      let nextX = obj.x + obj.vx;
      let nextY = obj.y + obj.vy;

      // Bounce off walls for demo visibility
      if (nextX < 0 || nextX > 640) {
        obj.vx *= -1;
        nextX = obj.x + obj.vx;
      }
      if (nextY < 0 || nextY > 480) {
        obj.vy *= -1;
        nextY = obj.y + obj.vy;
      }

      // Add small noise to simulate sensor jitter (the "raw" observation)
      const noisyX = nextX + (Math.random() - 0.5) * 1.2;
      const noisyY = nextY + (Math.random() - 0.5) * 1.2;

      const newHistory = [...obj.history, { 
        x: noisyX, 
        y: noisyY, 
        sx: nextX, // Smoothed/Ground Truth
        sy: nextY, // Smoothed/Ground Truth
        vx: obj.vx, 
        vy: obj.vy, 
        t: this.frameCount 
      }].slice(-50);
      
      // Generate prediction horizon
      const prediction = Array.from({ length: SYSTEM_CONFIG.PREDICTION_HORIZON }).map((_, i) => ({
        x: nextX + obj.vx * (i + 1),
        y: nextY + obj.vy * (i + 1),
        t: this.frameCount + i + 1
      }));

      return {
        ...obj,
        x: nextX,
        y: nextY,
        history: newHistory,
        prediction
      };
    });

    return this.objects;
  }
}