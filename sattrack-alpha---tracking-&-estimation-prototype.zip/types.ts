export interface HistoryPoint {
  x: number;
  y: number;
  sx: number; // Smoothed X
  sy: number; // Smoothed Y
  vx: number;
  vy: number;
  t: number;
}

export interface TrackedObject {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  history: HistoryPoint[];
  prediction: { x: number; y: number; t: number }[];
  color: string;
}

export interface MetricCardProps {
  label: string;
  value: string | number;
  unit?: string;
  description?: string;
  trend?: 'up' | 'down' | 'neutral';
}

export enum SectionID {
  OVERVIEW = 'overview',
  ARCHITECTURE = 'architecture',
  DEMO = 'demo',
  RESULTS = 'results',
  PREDICTION = 'prediction',
  METRICS = 'metrics',
  LIMITATIONS = 'limitations'
}