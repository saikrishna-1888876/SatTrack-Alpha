
export const SYSTEM_CONFIG = {
  RESOLUTION: '640x480',
  FRAME_RATE: 20,
  OBJECT_COUNT: 5,
  DETECTION_METHOD: 'Intensity-based Thresholding',
  TRACKING_ALGORITHM: 'Nearest-Neighbor + Kalman Filter',
  MOTION_MODEL: 'Constant Velocity',
  PREDICTION_HORIZON: 20, // frames
  PIXELS_PER_METER: 10,
};

export const COLORS = [
  '#3b82f6', // blue
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ef4444', // red
  '#a855f7', // purple
];
